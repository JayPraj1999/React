// import React, { useState } from 'react'

// function Data() {

//     const [checked, setChecked] = useState();
//     const [check, setCheck] = useState();


//   return (
//     <>
    
//         <h1>
//         <p id='text1'>You are a Citizen : {checked ? "Yes" : "No"}</p>
//         <p id='text2'>Are you over 21 : {check ? "Yes" : "No"} </p>
//         </h1>

//         <p>Are you citizen ?  <input type="checkbox" id='citizen' name='citizen' value="Yes" onChange={(event) => setChecked(event.target.checked)}/> </p>
//         <p>Are you over 21 ? <input type="checkbox" id='age' name='age' value="Yes" onChange={(event) => setCheck(event.target.checked)}/> </p>
//     </>
//   )
// }


import { useState, createContext, useContext } from "react";   //Import Statements


const UserContext = createContext();   //create new Context

function Data() {
    const [user, setUser] = useState();   //create state for first checkbox
    const [check, setCheck] = useState();  //create state for second checkbox

    return (
        <UserContext.Provider value={user}>

            {/* Check value of checkbox and use ternary operator if value is check the it define Yes otherwise No */}

            <h1>Are you a Citizen : {user ? "Yes" : "No"}   
                <p >Are you over 21 : {check ? "Yes" : "No"} </p>
            </h1>

        {/* Create onChange event to handle checkbox changes value and set new value and pass it to useState */}
        
            <p>Are you citizen ?  <input type="checkbox" id='citizen' name='citizen' onChange={(event) => setUser(event.target.checked)} /> </p>
            <p>Are you over 21 ? <input type="checkbox" id='age' name='age' onChange={(event) => setCheck(event.target.checked)} /> </p>

        </UserContext.Provider>
    );
}




export default Data