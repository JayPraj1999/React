import './App.css';
import Table from './Table';




function App() {
  return (
    <>
    
      <Table />
    
    </>
  );
}

export default App;
