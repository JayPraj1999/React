import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import Crud_Login from './Crud_Login';
import Sing_Up from './Sing_Up';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Home from './Home';
import Table from './Table';

function App() {
  return (
    <>
    
    <BrowserRouter>
    <ToastContainer></ToastContainer>
    <Routes>

    <Route path='/' element={<Home />} />
    <Route path='/sing-in' element={<Crud_Login />} />
    <Route path='/sign-up' element={<Sing_Up />} />
    <Route path='/table' element={<Table />} />



    </Routes>
    
    </BrowserRouter>

      {/* <Crud_Login />
      <Sing_Up /> */}
    
    </>
  );
}

export default App;
