import React, { useEffect, useState } from 'react'
import './App.css';
import { NavLink, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';



function Crud_Login() {

    const redirect=useNavigate();
    const [formvalue, setFormvalue] = useState({
        email: "",
        password: "",
    })

    const changeHandel = (e) => {
        setFormvalue({ ...formvalue, [e.target.name]: e.target.value });
        console.log(formvalue);
    }

    function validation() {
        let ans = true;
        if (formvalue.email == "") {
            toast.error("Email Field is Required");
            ans = false;
            return false;
        }
        if (formvalue.password == "") {
            toast.error("password Field is Required");
            ans = false;
            return false;
        }
        return ans;
    }

    const submitHandel = async (e) => {
        e.preventDefault();
        if (validation()) {
            const res = await axios.get(`http://localhost:3000/user?email=${formvalue.email}`);
            console.log(res.data);
            if (res.data.length > 0) {
                if (res.data[0].password == formvalue.password) {
                    if (res.data[0].status == "Unblock") {
                       
                        // session 
                        localStorage.setItem('uid',res.data[0].id);
                        localStorage.setItem('uname',res.data[0].name);

                        toast.success('Login Succees');
                        redirect('/');
                    }
                    else {
                        toast.error('User Blocked so Contact rajvi!');
                    }
                }
                else {
                    toast.error('Password incorrect!');
                }
            }
            else {
                toast.error('Email does nor exist !');
            }
        }
    }


  return (
    <>
    
    <div class="container">
        <div class="signin-form">
            <h2>Sign In</h2>
            <form method='post' onSubmit={submitHandel}>
                <div class="input-group">
                    <label for="username">Email</label>
                    <input value={formvalue.email} onChange={changeHandel} type="text" id="email" name="email" required />
                </div>
                <div class="input-group">
                    <label for="password">Password</label>
                    <input value={formvalue.password} onChange={changeHandel} type="password" id="password" name="password" required />
                </div>
                <button type="submit">Submit</button>
                <NavLink to='/sign-up'><button type="submit">Sign Up</button></NavLink>
            </form>
        </div>
    </div>
    
    </>
  )
}

export default Crud_Login