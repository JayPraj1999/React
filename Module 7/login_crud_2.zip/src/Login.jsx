import React from 'react'
import './App.css';

function Login() {
  return (
    <>
    
        <div className="body">
            
        </div>
    
    </>
  )
}

export default Login