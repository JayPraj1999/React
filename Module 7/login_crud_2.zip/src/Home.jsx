import React from 'react'
import './App.css';
import { NavLink, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';


function Home() {

    const redirect = useNavigate()

    const logout = () => {
        localStorage.removeItem('uid');
        localStorage.removeItem('uname');
        toast.success('Logout Success');
        redirect('/sing-in');
    }

  return (
    <>
    
        <h1>Hello !! Welcome to Home Page....</h1>

        {(() => {
                            if (localStorage.getItem('uid')) {
                                return (
                                    <a href="javascript:void(0)" onClick={logout} ><button>Logout</button></a>
                                )
                            }
                            else {
                                return (
                                    <NavLink to='/sing-in'>Login</NavLink>
                                )
                            }
                        })()}

    </>
  )
}

export default Home