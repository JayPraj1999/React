import React, { useEffect, useState } from 'react'
import './App.css';
import { NavLink } from 'react-router-dom';
import { toast } from 'react-toastify';
import axios from 'axios'

function Sing_Up() {

    const [formvalue, setFormvalue] = useState({
        name: "",
        email: "",
        password: "",
        mobile: ""
    })

    const changeHandel = (e) => {
        setFormvalue({ ...formvalue, id: new Date().getTime().toString(), status: "Unblock", [e.target.name]: e.target.value });
        console.log(formvalue);
    }

    function validation() {
        let ans = true;
        if (formvalue.name == "") {
            toast.error("Categories Image Field is Required");
            ans = false;
            return false;
        }
        if (formvalue.email == "") {
            toast.error("Categories image Field is Required");
            ans = false;
            return false;
        }
        if (formvalue.password == "") {
            toast.error("password image Field is Required");
            ans = false;
            return false;
        }
        if (formvalue.mobile == "") {
            toast.error("mobile image Field is Required");
            ans = false;
            return false;
        }
        return ans;
    }

    const submitHandel = async (e) => {
        e.preventDefault();
        if (validation()) {
            const res = await axios.get(`http://localhost:3000/user?email=${formvalue.email}`);
            console.log(res.data);
            if (res.data.length > 0) {
                toast.error('This email id already Registered !')
            }
            else {
                const res = await axios.post(`http://localhost:3000/user`, formvalue);
                setFormvalue({ ...formvalue, name: "", email: "", password: "", mobile: ""});
                toast.success('Signup Success');
            }
        }
    }



  return (
    <>
    
    <div class="container">
        <div class="signin-form">
            <h2>Sign Up</h2>
            <form method='post' onSubmit={submitHandel}>
                <div class="input-group">
                    <label for="username">Name</label>
                    <input onChange={changeHandel} value={formvalue.name} type="text" id="name" name="name" required/>
                </div>
                <div class="input-group">
                    <label for="email">Email</label>
                    <input onChange={changeHandel} value={formvalue.email} type="email" id="email" name="email" required/>
                </div>
                <div class="input-group">
                    <label for="mobile">mobile</label>
                    <input onChange={changeHandel} value={formvalue.mobile} type="text" id="mobile" name="mobile" required/>
                </div>
                <div class="input-group">
                    <label for="password">Password</label>
                    <input onChange={changeHandel} value={formvalue.password} type="password" id="password" name="password" required/>
                </div>

                <button type="submit">Submit</button>
                <NavLink to='/sing-in'>  <button type="submit">Sign In</button></NavLink>
                
            </form>
        </div>
    </div>
    
    </>
  )
}

export default Sing_Up